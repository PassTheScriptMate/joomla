<?php

// ################################################################
defined( '_JOMRES_INITCHECK' ) or die( '' );
// ################################################################

class plugin_info_bypass_plugin_manager
	{
	function __construct()
		{
		$this->data=array(
			"name"=>"bypass_plugin_manager",
			"category"=>"System",
			"marketing"=>"Displays and installs plugins that can be downloaded from Jomres.net, also allows you to install third party plugins.",
			"version"=>"1.5",
			'third_party_plugin_latest_available_version' => "http://www.fixmycomputermark.com/jomrespluginsinfo/bypass_plugin_manager.json",
			"lastupdate"=>"11/06/2017",
			"min_jomres_ver"=>"9.9.7",
  	  "authoremail" => "<a href=mailto:info@fixmycomputermark.com?subject=bypass_plugin_manager_v1.5>Email_Me</a>",
  "developer_page" => "http://www.fixmycomputermark.com/free-downloads/file/1-bypass_plugin_manager.html",
  "author" => "Mark",	
  "description" => "Updated for Jomres 9.9.15: rename shortcode_parser to jomres_shortcode_parser. This plugin bypasses Jomres New Plugin Manager. If you have a Jomres License this Plugin will let you see ALL your Plugins, be able to install or update these Plugins with any Jomres License, or install any Jomres Plugins thru Jomres Third party plugin Installer. Also, if you have a license that will not let you add more then one property, this plugin will let you add as many properties as you want. With this Plugin you will be able to use Jomres Online Booking System as long as you like."
			);
		}
	}
