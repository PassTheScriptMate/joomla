<?php
 
##################################################################
defined( '_JOMRES_INITCHECK' ) or die( '' );
##################################################################

jr_define('NO_LICENSE_MESSAGE', "You installed our bypass_plugin_manager! Great! You have now bypassed Jomres New Plugin Manager!");
